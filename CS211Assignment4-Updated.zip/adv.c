#include "adventure.h"

int main() {
	int ch;

	initscr();

	raw();
	cbreak();

	sizecheck();

	keypad(stdscr, TRUE);

	G_ELEMS *game = initialize_gamestate();
	MAZE *maze = NULL;
	maze = maze_load(maze, "mazes/maze1.txt", "mazes/maze1events.txt");
	PC *player = player_spawn(19, 17, 1, 3);

	/* Title screen */
	load_screen(game, "screens/0_ttl.txt");
	while ((ch = getch()) != 'p') {
		if (ch == KEY_F(2)) {
			game_over(game);
		}
		if (ch == 'h') {
			load_screen(game, "screens/1_hlp.txt");
		}
	}
	/* Redraw the gamespace so that p, e, or h don't show up */
	clear();	
	box(game->gamespace, 0, 0);
	refresh();

	/* Aesthetically preparing the game */
	maze_print(game->gamespace, player, maze);
	box(game->status, 0, 0);
	box(game->inventory, 0, 0);
	wrefresh(game->status);
	wrefresh(game->inventory);

	/* Main game loop and initial message */
	status_update(game->status, "You wake up in a strange dungeon.");
	move_player(game, player, maze);

	game_over(game);
	return 0;
}
