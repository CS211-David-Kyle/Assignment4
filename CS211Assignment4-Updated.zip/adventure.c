#include "adventure.h"

/* GAME UTILITY FUNCTIONS ================================================== */
G_ELEMS *initialize_gamestate()
/* Initializes the windows that we'll be using */
{
	int x_stat, x_gs, y_stat, y_gs, x_inven, y_inven;	
	x_stat = 55;
	y_stat = 10;
	x_gs = 55;
	y_gs = 20;
	x_inven = 55;
	y_inven = 3;
	G_ELEMS* game = malloc(sizeof(G_ELEMS));
	game->status = create_window(y_stat, x_stat, y_gs + 4, 5);
	game->gamespace = create_window(y_gs, x_gs, 1, 5);
	game->inventory = create_window(y_inven, x_inven, y_gs + 1, 5);
	return game;
}

WINDOW *create_window(int height, int length, int ypos, int xpos)
/* Constructor function for a new window */
{
	WINDOW *new = newwin(height, length, ypos, xpos);
	box(new, 0, 0);
	wrefresh(new);
	refresh();
	return new;
}


void free_gamestate(G_ELEMS *game)
/* Frees the gamestate */
{
	delwin(game->gamespace);
	delwin(game->status);
	free(game);
	return;
}

void game_over(G_ELEMS* game) 
/* Exiting procedure for the program */
{
	wrefresh(game->gamespace);
	wrefresh(game->status);
	free_gamestate(game);
	endwin();
	exit(0);	
}

//detect if terminal is too small.
//LINES and COLS are defined by ncurses
//it is size of terminal (LINES = y, COLS = x)
void sizecheck() {
	if ((LINES < MIN_ROWS) || (COLS < MIN_COLS)) {
		fprintf(stderr, "\n\r");
		fprintf(stderr, "ERROR: Terminal too small for proper gameplay.\n\r");
		fprintf(stderr, "Please re-size your terminal window and re-run the");
		fprintf(stderr, " program.\n\r");
		fprintf(stderr, 
			   "The terminal must have at least %i columns and %i rows.\n\r", 
			   MIN_COLS, MIN_ROWS);
		fprintf(stderr,
			    "NUM COLS/ROWS DETECTED: %d / %d\n\r", COLS, LINES);
		endwin();
		exit(0);
	}
	return;
}

void load_screen(G_ELEMS *g, char* name) {
/* Prints out the title screen to the gamespace, and waits for the player
   to either press F2 (to exit) or KEY_ENTER (to start the game)            */
	int i, j;
	int ch;
	char buffer[52];

	wclear(g->gamespace);
	box(g->gamespace, 0, 0);

	FILE *room_file = fopen(name, "r");
	if (room_file == NULL) {
		wprintw(g->status, "Error reading %s.\nAborting.", name);
		game_over(g);
	}

	while (fgets(buffer, 52, room_file)) 
		waddstr(g->gamespace, buffer);
		
	box(g->gamespace, 0, 0);
	wrefresh(g->gamespace);
	fclose(room_file);	
	return;
}
/* GAME UTILITY FUNCTIONS ================================================== */

/* MAZE UTILITY FUNCTIONS ================================================== */
MAZE* maze_load(MAZE* maze, char* map_file, char* events_file) 
/* Takes a file and fills in the maza data character by charcter, row by row 
/* Mallocs a maze if it's not initialized already                            */
{
	int row_lp, col_lp;
	char data;
	char event;
	
	if (maze == NULL) 
		maze = malloc(sizeof(MAZE));

	FILE* fp_data = fopen(map_file, "r");
	if (fp_data == NULL) {
		endwin();
		exit(0);
	}
	else {
		/* Loop for copying data from the map file */
		for (row_lp = 0; row_lp < NUM_ROWS; row_lp++) {
			for (col_lp = 0; col_lp < NUM_COLS; col_lp++) {
				if ((data = fgetc(fp_data)) == '\n') {
					col_lp--;
					continue;
				}
				maze->data[row_lp][col_lp] = data;
			}
		}
		fclose(fp_data);
	}

	FILE* fp_events = fopen(events_file, "r");
	if (fp_events == NULL) {
		endwin();
		exit(0);
	}
	else {
		/* Loop for copying events for the events file */
		for (row_lp = 0; row_lp < NUM_ROWS; row_lp++) {
			for (col_lp = 0; col_lp < NUM_COLS; col_lp++) {
				if ((event = fgetc(fp_events)) == '\n') {
					col_lp--;
					continue;
				}
				/* Convert ascii digit to logical int digit */
				if (event >= '0' && event <= '9')
					maze->events[row_lp][col_lp] = event - '0';
				else 
					maze->events[row_lp][col_lp] = event;
			}
		}
		fclose(fp_events);
	}
	return maze;
}

void maze_print(WINDOW* gamespace, PC* player, MAZE* maze) 
/* Prints out the maze */
{
	wclear(gamespace);
	box(gamespace, 0, 0);
	int row_lp, col_lp;
	for (row_lp = 1; row_lp < NUM_ROWS; row_lp++) {
		for (col_lp = 1; col_lp < NUM_COLS; col_lp++) {
			mvwprintw(gamespace, row_lp, col_lp, "%c", 
				      maze->data[row_lp][col_lp]);		
		} 
		mvwprintw(gamespace, row_lp, col_lp, "\n");
	}
	mvwprintw(gamespace, player->y_pos, player->x_pos, "%c", PLAYER);
	box(gamespace, 0, 0);
	wrefresh(gamespace);
	return;
}
/* MAZE UTILITY FUNCTIONS ================================================== */

/* INVENTORY UTILITY FUNCTIONS ============================================= */
inventory_list* create_inv_node(char item) 
/* Creates a new node for the inventory */
{
	inventory_list* new = malloc(sizeof(inventory_list));
	new->item = item;
	new->next = NULL;
	return new;
}

void inv_update(WINDOW *inv, PC* player)
/* Prints out the linked list to the inventory window */
{
	wclear(inv);
	box(inv, 0, 0);
	int x=1;
	char c='1';
	inventory_list* prev = NULL;
	inventory_list* head = player->inventory;
	while (player->inventory != NULL) {
		mvwaddch(inv, 1, x, player->inventory->item);
		mvwaddch(inv, 2, x, c);
		x+=2;
		c++;
		prev = player->inventory;
		player->inventory = player->inventory->next;
		prev->next = player->inventory;
	}
	player->inventory = head;
	wrefresh(inv);
	return;	
}

void add_to_inv(char item, PC* player) 
/* Appends an item to the end of the inventory linked list */
{
	if (player->inventory == NULL) {
		player->inventory = create_inv_node(item);
		player->inv_size++;	
		return;
	}
	else {
		inventory_list* prev = NULL;
		inventory_list* head = player->inventory;
		while (player->inventory != NULL && player->inventory->next != NULL) {
			prev = player->inventory;
			player->inventory = player->inventory->next;
			prev->next = player->inventory;
		}
		player->inventory->next = create_inv_node(item);
		player->inv_size++;	
		player->inventory = head;
		return;
	}
}

void use_item(G_ELEMS* game, MAZE* maze, PC *player, int item_number)
/* Uses the item at the given slot number, does an item lookup*/
{
	int x = player->x_pos;
	int y = player->y_pos;
	item_number -= '0';
	int i=1;
	if (item_number > player->inv_size){
		status_update(game->status,
					"I don't have that many items.");
		return;
	}
	else {
		switch(item_number) {
			/* Torch */
			case 1:
				if (player->sight_radius == 3) {
					status_update(game->status, 
								  "I re-ignited the torch.");
					player->inventory->item = EMPTY_SLOT;
					player->sight_radius = 6;
					player_sight(game->gamespace, player, maze);
					break;
				} 
				else if (player->sight_radius == 6) {
					status_update(game->status,
						 		  "I extinguished the torch.");
					player->inventory->item = TORCH;
					player->sight_radius = 3;
					player_sight(game->gamespace, player, maze);
					break;					
				}
				else {
					break;
				}
			case 2:
				if (maze->events[y][x] == 8) {
					status_update(game->status, "Let's try this door.");
					mvwprintw(game->status, 2, 1, "The key worked!");
					wrefresh(game->status);
					/* Update map and event squares */
					maze->data[y][x + 1] = UNLKED_DOOR;
					maze->events[y][x] = 0;
					break;
				}
				else {
					status_update(game->status, "An old, iron key.");
					break;
				}
			case 3: 
				status_update(game->status, "This is what the note says..");
				note_dialogue(game);
				return;
		}
	}
	inv_update(game->inventory, player);
}

void inventory_free(inventory_list* inventory)
/* Frees the inventory iteratively */
{
	inventory_list* temp = NULL;
	while (inventory != NULL) {
		temp = inventory;
		inventory = inventory->next;
		free(temp);
	}
	return;
}
/* INVENTORY UTILITY FUNCTIONS ============================================= */

/* STATUS MESSAGE UTILITY FUNCTIONS ======================================== */
void status_update(WINDOW* status, char* message)
/* Updates the status window (not the player's status!) with the message */
{
	wclear(status);
	mvwprintw(status, 1, 1, message);
	box(status, 0, 0);
	wrefresh(status);
}

void colored_lever_dialogue(G_ELEMS* game, MAZE* maze, 
	                        int y_pos, int x_pos, char* color)
/* A way to clean up some code. y_pos and x_pos refer to the location of the 
   lever itself 														    */
{
	WINDOW* status = game->status;

	/* Lever is pulled up; push it back down */
	if (maze->data[y_pos][x_pos] == LEVER_UP) {
		maze->data[y_pos][x_pos] = LEVER_DOWN;
		wclear(status);
		box(status, 0, 0);
		mvwprintw(status, 1, 1, "There's a %s lever here.", color);
		mvwprintw(status, 2, 1, "..."); 
		mvwprintw(status, 3, 1, "...");
		mvwprintw(status, 4, 1, "I decided to push on the lever.");
		mvwprintw(status, 5, 1, 
			      "Some gears above me are clicking and spinning now.");
		/* This code below updates the lever's icon in real time */
		wrefresh(status);
		mvwaddch(game->gamespace, y_pos, x_pos, LEVER_DOWN);
		wrefresh(game->gamespace);
		return;
	}
	/* Lever is pulled down; pull it back up */
	else {
		maze->data[y_pos][x_pos] = LEVER_UP;
		wclear(status);
		box(status, 0, 0);
		mvwprintw(status, 1, 1, "This %s lever has been pulled down.", color);
		mvwprintw(status, 2, 1, "...");
		mvwprintw(status, 3, 1, "...");
		mvwprintw(status, 4, 1, "I decided to pull the lever back.");
		mvwprintw(status, 5, 1, "The gears have stopped moving now.");
		wrefresh(status);
		/* This code below updates the lever's icon in real time */
		mvwaddch(game->gamespace, y_pos, x_pos, LEVER_UP);
		wrefresh(game->gamespace);
		return;
	}	
}

void note_dialogue(G_ELEMS* game)
/* Dialogue for the note to save some lines of code */
{
	WINDOW* status = game->status;
	mvwprintw(status, 2, 1, "~-------------------------------------~");
	mvwprintw(status, 3, 1, "Solve the levers one at a  time");
	mvwprintw(status, 4, 1, "     And the doors will      ");
	mvwprintw(status, 5, 1, "Just    find           open");
	mvwprintw(status, 6, 1, "     th ");
	mvwprintw(status, 7, 1, "  rig t  c mbi at on and o der...");
	mvwprintw(status, 8, 1, "~-------------------------------------~");
	wrefresh(status);
	return;
}
/* STATUS MESSAGE UTILITY FUNCTIONS ======================================== */

/* PLAYER UTILITY FUNCTIONS AND MAIN GAME LOGIC ============================ */
PC* player_spawn(int x, int y, int status, int sight_radius)
/* Constructor function for player; should really only be used once */
{
	PC* player = malloc(sizeof(PC));
	player->x_pos = x;
	player->y_pos = y;
	player->status = status;
	player->sight_radius = sight_radius;
	player->inventory = NULL;
	player->inv_size = 0;
	return player;
}

int isBlocked(PC* player, MAZE* maze, int dst_x, int dst_y)
/* Line of sight implementation with a lengthy description of how it works */
{
	/* We're drawing a ray from the player to the dst coordinates */
	int curr_x = player->x_pos;
	int curr_y = player->y_pos;

	/* We don't want to block out a wall that we can see; block out the square
	   after that */
	int existsObstacle = 0;
	int blocksAfter = 0;

	int dx = abs(dst_x - player->x_pos);
	int dy = abs(dst_y - player->y_pos);

	/* n is the max number of squares that we can visit; it doesn't matter if
	   we check a square more than once                                     */
	int n = 1 + dx + dy;

	/* growth_track keeps track of whether the line has passed through into a
	   square either vertically or horizontally (or both, when it equals 0).

	   From our starting point, we know that if growth_track > 0, then we will  
	   we will run into a horizontally adjacent square faster than a vertically
	   adjacent square. 

	   So, assuming growth_track is > 0, we then update our current x position
	   either by 1 or -1, depending on dx, and then update growth_track by 
	   subtracting dy -- because we progressed our current position on the line
	   and we need to account for the change in y position as well.

	   We follow a very similar process for when growth_track is < 0.

	   When growth_track is 0, then we know that we have the line y = x or 
	   y = -x. So, we just increase/decrease both the curr_x and curr_y at the 
	   same time. 															 

	   Idea of this square-by-square traversal was from:
	   http://playtechs.blogspot.com/2007/03/raytracing-on-grid.html         */

	int growth_track = dx - dy;

	int x_inc = 0;
	int y_inc = 0;

	/* Find out if it's increasing in the x direction */
	if (player->x_pos < dst_x)        
		x_inc = 1;
	// else if (player->x_pos == dst_x)  
	// 	x_inc = 0;
	else 							  
		x_inc = -1;
	

	/* Find out if it's increasing in the y direction */
	if (player->y_pos < dst_y) 
		y_inc = 1;
	// else if (player->y_pos == dst_y)
	// 	y_inc = 0;
	else 
		y_inc = -1;
	
	while (n > 0) {
		if (existsObstacle)
			blocksAfter++;

		if (maze->data[curr_y][curr_x] == CLOSED_DOOR ||
			maze->data[curr_y][curr_x] == WALL        ||
			maze->data[curr_y][curr_x] == BRKN_WALL) {
			existsObstacle = 1;	
		}

		if (growth_track > 0) {
			curr_x += x_inc;
			growth_track -= dy;
		}
		else if (growth_track == 0) {
			curr_x += x_inc;
			growth_track -= dy;
			curr_y += y_inc;
			growth_track += dx;
			n--;
		}
		else {
			curr_y += y_inc;
			growth_track += dx;
		}
		n--;
	}
	if (existsObstacle > 0 && blocksAfter > 0)
		return 1;
	else 
		return 0;
}

void player_sight(WINDOW* gamespace, PC* player, MAZE* maze)
/* Prints out to the gamespace the player's line of sight */ 
{	
	int row_lp, col_lp;
	int x_pos = player->x_pos;
	int y_pos = player->y_pos;

	int dx;
	int dy;
	int sight = player->sight_radius;

	wclear(gamespace);
	for (row_lp = y_pos - sight; row_lp <= y_pos + sight; row_lp++) {
		/* Check if out of bounds for rows */
		if (row_lp >= NUM_ROWS - 1 || row_lp < 1)
			continue;		
		for (col_lp = x_pos - sight; col_lp <= x_pos + sight; col_lp++) {
			/* Check if out of bounds for cols */
			if (col_lp >= NUM_COLS - 1 || col_lp < 1)
				continue;

			dx = col_lp - x_pos;
			dy = row_lp - y_pos;
			/* Vision is bounded by an ellipse; each "square" in the console
			   has increased heights and so a circle in the console looks like
			   an ellipse              										 */

			if (isBlocked(player, maze, col_lp, row_lp))
				continue;

			if (((dx * dx) + (dy * dy * 2)) <= (sight * sight))
				mvwaddch(gamespace, row_lp, col_lp, 
						 maze->data[row_lp][col_lp]);
		}
	}
	mvwprintw(gamespace, y_pos, x_pos, "%c", PLAYER);
	box(gamespace, 0, 0);
	wrefresh(gamespace);
	return;
}

void player_action(G_ELEMS* game, PC* player, MAZE* maze)
/* Enables certain actions/events when done over a certain square; the events
   are laid out in maze->events                                             */
{
	WINDOW* status = game->status;
	int x_pos = player->x_pos;
	int y_pos = player->y_pos;

	/* Basic square information */
	if (maze->events[y_pos][x_pos] == 0) {
		status_update(status, "There doesn't seem to be anything here.");
		return;
	}
	/* First door in the game, used to get the key */
	else if (maze->events[y_pos][x_pos] == 1) {
		status_update(status, "There's a door here.");
		mvwprintw(status, 2, 1, "It looks like it hasn't been used in ages.");
		mvwprintw(status, 3, 1, "I could probably open it with some effort.");
		wrefresh(status);
		/* Set up the next event trigger */
		maze->events[y_pos][x_pos] = 'a';
		return;
	}
	/* Breakable wall used to get the torch */
	else if (maze->events[y_pos][x_pos] == 2) {
		wclear(status);
		mvwprintw(status, 1, 1, "There's an old, crumbling wall here.");
		mvwprintw(status, 2, 1, "It looks like I can take out some bricks.");
		box(status, 0, 0);
		wrefresh(status);
		/* Update the event map to reflect being able to tear down the wall */
		maze->events[y_pos][x_pos] = 3;
		return;
	}
	/* Descriptive text for breaking down the wall */
	else if (maze->events[y_pos][x_pos] == 3) {
		wclear(status);
		mvwprintw(status, 1, 1, "7... 8...");
		mvwprintw(status, 2, 1, "!");
		mvwprintw(status, 3, 1, "The wall collapsed on itself!");
		mvwprintw(status, 4, 1, "8 bricks did it for it.");
		box(status, 0, 0);
		wrefresh(status);
		/* Update the event map to reflect the wall becoming rubble */
		maze->events[y_pos][x_pos] = 0;
		maze->data[y_pos + 1][x_pos] = RUBBLE;
		/* Allows the wall to be updated in "real" time. Without it, the wall
		   only changes after the player moves     			                */
		player_sight(game->gamespace, player, maze);		
		return;
	}
	/* Finding the torch */
	else if (maze->events[y_pos][x_pos] == 4) {
		status_update(status, "It looks like there's a torch on the ground.");
		return;
	}
	/* Picking up the torch */
	else if (maze->events[y_pos][x_pos] == 5) {
		add_to_inv(TORCH, player);
		inv_update(game->inventory, player);
		status_update(status, "I picked up a torch.");
		/* Update map squares */
		maze->events[y_pos][x_pos] = 0;
		maze->data[y_pos][x_pos] = EMPTY;
		/* Update the tile about finding the tourch */
		maze->events[y_pos - 1][x_pos] = 0;
		return;
	}
	/* Picking up the key */
	else if (maze->events[y_pos][x_pos] == 6) {
		add_to_inv(KEY, player);
		inv_update(game->inventory, player);
		status_update(status, "I picked up a decently large key.");
		/* Update map and events */
		maze->data[y_pos][x_pos] = EMPTY;
		maze->events[y_pos][x_pos] = 7;
		return;
	}
	/* Descriptive text of the room with the key */
	else if (maze->events[y_pos][x_pos] == 7) {
		status_update(status, "It looks like I'm in an art gallery.");
		mvwprintw(status, 2, 1, "There are pictures of beautiful landscapes.");
		mvwprintw(status, 3, 1, "...");
		mvwprintw(status, 4, 1, "Hm.");
		wrefresh(status);
		return;
	}
	/* General text for locked doors */
	else if (maze->events[y_pos][x_pos] == 8) {
		status_update(status, "There's a giant metal door here. It's locked.");
		return;
	}
	/* Heh. */
	else if (maze->events[y_pos][x_pos] == 9) {
		status_update(status, "I'm under a door. Not much to say.");
		return;
	}
	/* Text for using the key on the locked door in maze1 */
	else if (maze->events[y_pos][x_pos] == 'a') {
		status_update(status, "With some effort, the door budged open.");
		/* Update the map and events */
		maze->events[y_pos][x_pos] = 0;
		maze->data[y_pos + 1][x_pos] = UNLKED_DOOR;
		return;
	}
	/* Load map2 from map1 */
	else if (maze->events[y_pos][x_pos] == 'b') {
		status_update(status,
		              "I walked down a long hallway for seemingly hours.");
		/* Update the in-memory maze for the new map */
		maze = maze_load(maze, "mazes/maze2.txt", "mazes/maze2events.txt");
		/* Change the player position */
		player->x_pos = 2;
		player->y_pos = 13;
		player_sight(game->gamespace, player, maze);
	}
	/* Interacting with the cyan lever */
	else if (maze->events[y_pos][x_pos] == 'c') {
		colored_lever_dialogue(game, maze, y_pos, x_pos - 1, "cyan");
		return;
	}
	/* Open the door in the second map, to access the red lever */
	else if (maze->events[y_pos][x_pos] == 'd') {
		if (maze->data[y_pos][x_pos - 1] == LEVER_UP) {
			maze->data[y_pos][x_pos - 1] = LEVER_DOWN;
			status_update(status, "There's a lever here.");
			mvwprintw(status, 2, 1, "...");
			mvwprintw(status, 3, 1, "...");
			mvwprintw(status, 4, 1, "I decided to push on the lever.");
			mvwprintw(status, 5, 1, "I hear something being moved behind me.");
			wrefresh(status);
			/* Updates the lever's icon in real time */
			player_sight(game->gamespace, player, maze);
			return;
		}
		else {
			/* Prevent players from opening the door that this lever is linked
			   to 															 */
			maze->data[y_pos][x_pos - 1] = LEVER_UP;
			status_update(status, "This lever has been pulled down.");
			mvwprintw(status, 2, 1, "...");
			mvwprintw(status, 3, 1, "...");
			mvwprintw(status, 4, 1, "I tried to pull the lever back.");
			mvwprintw(status, 5, 1, "...It's stuck.");
			wrefresh(status);
			/* Open the door and update the maze map and events */
			maze->data[9][19] = UNLKED_DOOR;
			maze->events[10][19] = 0;
			return;
		}
	}
	/* Fake wall. */
	else if (maze->events[y_pos][x_pos] == 'f') {
		status_update(status, 
					  "Here's another wall that doesn't look too sturdy.");
		mvwprintw(status, 2, 1, "...");
		mvwprintw(status, 3, 1, "I managed to take down the wall, but..");
		mvwprintw(status, 4, 1, "...");
		mvwprintw(status, 5, 1, "There's nothing behind it. I feel cheated.");
		wrefresh(status);
		maze->data[y_pos - 1][x_pos] = RUBBLE;
		maze->events[y_pos][x_pos] = 0;
		player_sight(game->gamespace, player, maze);
	}
	/* Descriptive text for the small room in map2 */
	else if (maze->events[y_pos][x_pos] == 'h') {
		status_update(status, "This is just an empty room.");
		return;
	}
	/* Final room description text */
	else if (maze->events[y_pos][x_pos] == 'i') {
		status_update(status, "This room's.. an abandoned throneroom.");
		return;
	}
	/* Interacting with the red lever */
	else if (maze->events[y_pos][x_pos] == 'r') {
		colored_lever_dialogue(game, maze, y_pos - 1, x_pos, "red");
		return;
	}
	/* Interacting with the lever that makes the shortcut to the cyan lever */
	else if (maze->events[y_pos][x_pos] == 's') {
		status_update(status, "Here's a lever with a danger sign above it.");
		mvwprintw(status, 2, 1, "Well, I'm -am- stuck in a castle-dungeon.");
		mvwprintw(status, 3, 1, "...Here goes...");
		mvwprintw(status, 3, 1, "...");
		mvwprintw(status, 4, 1, "...nothing?");
		mvwprintw(status, 5, 1, "BOOM!");
		mvwprintw(status, 6, 1, "Huh. Looks like a path opened up.");
		wrefresh(status);
		/* Change the walls to empty spaces for the shortcut */
		maze->data[y_pos][x_pos - 1] = EMPTY;
		maze->data[y_pos][x_pos - 2] = EMPTY;
		maze->data[y_pos][x_pos - 3] = EMPTY;
		/* And update the events accordingly */
		maze->events[y_pos][x_pos] = 0;
		maze->events[y_pos][x_pos - 1] = 0;
		/* Real time update */
		player_sight(game->gamespace, player, maze);
		return;
	}
	/* Interacting with the yellow lever */
	else if (maze->events[y_pos][x_pos] == 'y') {
		colored_lever_dialogue(game, maze, y_pos, x_pos + 1, "yellow");
		return;
	}
	/* Green lever dialogue */
	else if (maze->events[y_pos][x_pos] == 'G') {
		status_update(status, "Here's a green lever.");
		mvwprintw(status, 2, 1, "...");
		mvwprintw(status, 3, 1, "What happens if I pull it..");
		/* Check if the red/blue levers are the only levers activated */
		if (maze->data[5][22] == LEVER_UP   &&
			maze->data[17][5] == LEVER_DOWN &&
			maze->data[17][44] == LEVER_DOWN) {
			mvwprintw(status, 4, 1, "...huh.");
			mvwprintw(status, 5, 1, "The lever moved pretty easily.");
			mvwprintw(status, 6, 1, "Some floor mechanism removed the lever.");
			wrefresh(status);
			/* Update map and event data */
			maze->data[y_pos][x_pos + 1] = WALL;
			maze->events[y_pos][x_pos] = 'i';
			player_sight(game->gamespace, player, maze);
			return;
		}
		else {
			mvwprintw(status, 4, 1, "...It's not budging.");
			mvwprintw(status, 5, 1, "Maybe I'm missing something?");
			wrefresh(status);
			return;
		}

	}
	/* Orange lever dialogue */
	else if (maze->events[y_pos][x_pos] == 'O') {
		status_update(status, "Here's an orange lever.");
		mvwprintw(status, 2, 1, "...");
		mvwprintw(status, 3, 1, "What happens if I pull it..");
		/* Check if the red/blue levers are the only levers activated */
		if (maze->data[5][22] == LEVER_DOWN &&
			maze->data[17][5] == LEVER_UP   &&
			maze->data[17][44] == LEVER_DOWN) {
			mvwprintw(status, 4, 1, "...huh.");
			mvwprintw(status, 5, 1, "The lever moved pretty easily.");
			mvwprintw(status, 6, 1, "Some floor mechanism removed the lever.");
			wrefresh(status);
			/* Update map and event data */
			maze->data[y_pos][x_pos + 1] = WALL;
			maze->events[y_pos][x_pos] = 'i';
			player_sight(game->gamespace, player, maze);
			return;
		}
		else {
			mvwprintw(status, 4, 1, "...It's not budging.");
			mvwprintw(status, 5, 1, "Maybe I'm missing something?");
			wrefresh(status);
			return;
		}
	}

	/* Purple lever dialogue */
	else if (maze->events[y_pos][x_pos] == 'P') {
		status_update(status, "Here's a purple lever.");
		mvwprintw(status, 2, 1, "...");
		mvwprintw(status, 3, 1, "What happens if I pull it..");
		/* Check if the red/blue levers are the only levers activated */
		if (maze->data[5][22] == LEVER_DOWN &&
			maze->data[17][5] == LEVER_DOWN &&
			maze->data[17][44] == LEVER_UP) {
			mvwprintw(status, 4, 1, "...huh.");
			mvwprintw(status, 5, 1, "The lever moved pretty easily.");
			mvwprintw(status, 6, 1, "Some floor mechanism removed the lever.");
			wrefresh(status);
			/* Update map and event data */
			maze->data[y_pos][x_pos + 1] = WALL;
			maze->events[y_pos][x_pos] = 'i';
			player_sight(game->gamespace, player, maze);
			return;
		}
		else {
			mvwprintw(status, 4, 1, "...It's not budging.");
			mvwprintw(status, 5, 1, "Maybe I'm missing something?");
			wrefresh(status);
			return;
		}

	}
	/* Text for the note describing how to open the final door */
	else if (maze->events[y_pos][x_pos] == '?') {
		status_update(status, "I found a note. It says....");
		note_dialogue(game);
		add_to_inv(NOTE, player);
		inv_update(game->inventory, player);
		/* Update the map and events */
		maze->data[y_pos][x_pos] = EMPTY;
		maze->events[y_pos][x_pos] = 0;
		return;
	}
	/* Final door opening */
	else if (maze->events[y_pos][x_pos] == 'L') {
		status_update(status, "This is a gigantic dark iron wall. It's warm.");
		if (maze->data[3][47] == WALL &&
			maze->data[6][45] == WALL &&
			maze->data[10][47] == WALL) {
			/* Update map and events */
			maze->data[y_pos][x_pos + 1] = EMPTY;
			maze->events[y_pos][x_pos] = 0;
			mvwprintw(status, 2, 1, "...");
			mvwprintw(status, 3, 1, "It's... opening.");
			wrefresh(status);
			player_sight(game->gamespace, player, maze);
			return;
		}
		else {
			mvwprintw(status, 2, 1, "Hmm..");
			mvwprintw(status, 3, 1, "Let's see if there's a hidden switch.");
			mvwprintw(status, 4, 1, "..Nope. It's not going to move.");
			wrefresh(status);
			return;
		}
	}
	/* Outside descriptive text */
	else if (maze->events[y_pos][x_pos] == 'Z') {
		status_update(status, "Grass.. has never been this comforting.");
		return;
	}
	/* Ending trigger */
	else if (maze->events[y_pos][x_pos] == 'E') {
		load_screen(game, "screens/2_end.txt");
		sleep(5);
		inventory_free(player->inventory);
		free(maze);
		free(player);
		game_over(game);
		return;
	}
	return;
}

int valid_move(PC* player, MAZE* maze, int x, int y) 
/* Checks if the player can move in a certain direction, given by the x and y 
   parameters. A player can't move if they're blocked by a wall, a locked door,
   or by the boundaries of the gamespace window                              */ 
{
	/* Check if the player's trying to go out of bounds */
	if (player->x_pos + x >= NUM_COLS - 1 || player->x_pos + x < 1)
		return 0;
	else if (player->y_pos + y >= NUM_ROWS - 1|| player->y_pos + y < 1)
		return 0;
	/* Check for obstructor squares */
	else if (maze->data[player->y_pos + y][player->x_pos + x] == CLOSED_DOOR ||
		     maze->data[player->y_pos + y][player->x_pos + x] == BRKN_WALL   ||
			 maze->data[player->y_pos + y][player->x_pos + x] == WALL        ||
			 maze->data[player->y_pos + y][player->x_pos + x] == LEVER_UP    ||
			 maze->data[player->y_pos + y][player->x_pos + x] == LEVER_DOWN) 
		return 0;
	/* Destination square is empty, return true */
	else {
		player->x_pos += x;
		player->y_pos += y;
		return 1;
	}
}

void move_player(G_ELEMS* game, PC* player, MAZE* maze)
{
	int ch;
	player_sight(game->gamespace, player, maze);

	while ((ch = getch()) != KEY_F(2)) {
		switch (ch) {
			/* case space bar */
			case ' ':
				player_action(game, player, maze);
				break; 	
			case KEY_RIGHT:
				if (valid_move(player, maze, 1, 0)) {
					player_sight(game->gamespace, player, maze);
					status_update(game->status, "I walked to my right.");
					break;
				}
				else {
					status_update(game->status, 
						          "There's something to my right.");
					break;
				}
			case KEY_LEFT:
				if (valid_move(player, maze, -1, 0)) {
					player_sight(game->gamespace, player, maze);
					status_update(game->status, "I walked to my left.");
					break;
				}
				else {
					status_update(game->status, 
						          "There's something to my left.");
					break;
				}
			case KEY_UP:
				if (valid_move(player, maze, 0, -1)) {
					player_sight(game->gamespace, player, maze);
					status_update(game->status, "I walked forward.");
					break;
				}
				else {
					status_update(game->status, 
						          "There's something in front of me.");
					break;
				}
			case KEY_DOWN:
				if (valid_move(player, maze, 0, 1)) {
					player_sight(game->gamespace, player, maze);
					status_update(game->status, 
						          "I took a step backwards.");
					break;
				}
				else {
					status_update(game->status, 
						          "There's something behind me.");
					break;
				}
			case '1': case '2': case '3': case '4': case '5': case '6': 
			case '7': case '8': case '9':
				use_item(game, maze, player, ch);
				break;
			} /* End of switch statement */
		}
}
/* PLAYER UTILITY FUNCTIONS AND MAIN GAME LOGIC ============================ */