#include <ncurses.h>
#include <stdlib.h>
#include <string.h>
#include "math.h"

#define NUM_ROWS    20
#define NUM_COLS    55
#define MIN_ROWS    35
#define MIN_COLS    80
#define EMPTY       '.'
#define PLAYER      'P'
#define WALL		'#'
#define BRKN_WALL   '%'
#define RUBBLE      '*'
#define NEXT_LEVEL  '>'
#define CLOSED_DOOR 'X'
#define UNLKED_DOOR 'O'
#define STATUE      '@'

#define LEVER_UP    '/'
#define LEVER_DOWN  '\\'

#define EMPTY_SLOT  '_'
#define TORCH       'T'
#define KEY         '<'
#define NOTE        '?'

typedef struct game_win {
	WINDOW *inventory;
    WINDOW *gamespace;
    WINDOW *status;
} G_ELEMS;

typedef struct inventory_list {
	char item;
	struct inventory_list* next;
} inventory_list;

typedef struct player{
	int x_pos;
	int y_pos;
	int status;
	int sight_radius;
	inventory_list* inventory;
	int inv_size;
} PC;


typedef struct MAZE {
	char data[NUM_ROWS][NUM_COLS];
	char events[NUM_ROWS][NUM_COLS];
} MAZE;	

G_ELEMS *initialize_gamestate();
WINDOW *create_window(int, int, int, int);
void free_gamestate(G_ELEMS*);
void game_over(G_ELEMS* game);
void sizecheck();
void load_screen(G_ELEMS *g, char* name);

MAZE* maze_load(MAZE* maze, char* map_file, char* events_file);
void maze_print(WINDOW* gamespace, PC* player, MAZE* maze);

inventory_list* create_inv_node(char item);
void inv_update(WINDOW *inv, PC* player);
void add_to_inv(char item, PC* player);
void use_item(G_ELEMS* game, MAZE* maze, PC *player, int item_number);

void status_update(WINDOW* status, char* message);
void colored_lever_dialogue(G_ELEMS* game, MAZE* maze, 
	                        int y_pos, int x_pos, char* color);
void note_dialogue(G_ELEMS* game);

PC* player_spawn(int x, int y, int status, int sight_radius);
int isBlocked(PC* player, MAZE* maze, int dst_x, int dst_y);
void player_sight(WINDOW* gamespace, PC* player, MAZE* maze);
void player_action(G_ELEMS* game, PC* player, MAZE* maze);
int valid_move(PC* player, MAZE* maze, int x, int y);
void move_player(G_ELEMS* game, PC* player, MAZE* maze);