Thanks to http://patorjk.com/software/taag/ for the text to ascii art generator, used to generate the title name.

Project by David Tag and Kyle Tulipano.
